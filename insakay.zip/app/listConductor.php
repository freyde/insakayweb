<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class listConductor extends Model
{
    //
}
