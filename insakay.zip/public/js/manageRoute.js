var openLand = document.getElementById('addLand');

openLand.onclick = function() {
    alert("YES!")
}