<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>INSAKAY-Admin-Login</title>
  <script src="https://www.gstatic.com/firebasejs/5.8.1/firebase.js"></script>
  <script src="https://cdn.firebase.com/libs/firebaseui/3.1.1/firebaseui.js"></script>
  <script src="https://www.gstatic.com/firebasejs/5.8.1/firebase-auth.js"></script>
</head>

<body>

<div id="logindiv">
<h1>Admin Log in</h1>

Email: <input type="email" placeholder="Email. . ." id="aemail"> <br>
Password: <input type="password" placeholder="Password. . ." id="apassword">
<button onclick="alogin()">Log in</button>
</div>

<div id="userdiv">
  UserDiv!
  <a href='register'>Register</a>
  <button onclick="alogout()">Logout</button>
</div>
  
<div id="admindiv">
  AdminDiv!
  <button onclick="alogout()">Logout</button>
</div>

<script type="text/javascript" src="js/firebase.js"></script>
<script type="text/javascript" src="js/index.js"></script>

</body>
</html>