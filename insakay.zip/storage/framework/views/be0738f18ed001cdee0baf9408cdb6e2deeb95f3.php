<?php $__env->startSection('content'); ?>

<h3 class="font-weight-bolder ml-3 mt-3 mb-5">Conductors Daily Report</h3>

<input type="hidden" id="uid" value="<?php echo e($uid); ?>">
<div class="container">
  <?php if($keys != null): ?>
    <?php $__currentLoopData = $keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="dropdown">
        <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown"><?php echo e(str_replace("_", " ",str_replace("-", ".", $key))); ?></button>
        <div class="dropdown-menu mt-0">
        <?php $__currentLoopData = $reports[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php    
        $raw = explode("_", $cond['fileName']);
        $a = str_replace(".csv", "", $raw[3]);
        $fName = $a.'-'.$raw[1].'-'.$raw[2];
        $date = date("F j, Y", strtotime($fName));
        ?>
            <label class="dropdown-item pr-2 pb-1" id="<?php echo e($cond['fileName']); ?>" onClick="download(this.id); return false" href="#"><?php echo e($date); ?><img class="ml-4 mr-2 mb-0" src="<?php echo e(URL::asset('img/download.png')); ?>"></label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
  <table class="table">
    <thead>
        <tr align="center">
            <th>No Reports Found</th>
        </tr>
    </thead>
  </table>
  <?php endif; ?>
</div>

<script type="text/javascript" src="<?php echo e(URL::asset('js/reports.js')); ?>"></script>
<!-- <script type="text/javascript" src="<?php echo e(URL::asset('js/firebase.js')); ?>"></script> -->
<?php $__env->stopSection(); ?>
</html>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>