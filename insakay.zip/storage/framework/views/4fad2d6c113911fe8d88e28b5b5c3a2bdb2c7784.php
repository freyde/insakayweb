<?php $__env->startSection('content'); ?>

<body>
<ol class="breadcrumb">
<h5>Welcome <?php echo session()->get('uid') ?></h5>
  <li class="breadcrumb-item"><a href="/controlpanel" target="contentall">Conductors</a></li>
  <li class="breadcrumb-item"><a href="#">Buses</a></li>
  <li class="breadcrumb-item"><a href="#">Route</a></li>
  <li class="breadcrumb-item"><a href="#">Fare</a></li>
  <li class="breadcrumb-item"><a href="#">Reports</a></li>
</ol>


<div class="contents">
<input type="submit" class="btn btn-secondary" value="＋Conductor" id="addCond">
</div>

<div class="main-container">
  <table class="table table-hover">
    <thead>
      <tr>
        <th scope="col">Id</th>
        <th scope="col">First Name</th>
        <th scope="col">Middle Name</th>
        <th scope="col">Last Name</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">1</th>
        <td>Jeffrey</td>
        <td>Morabe</td>
        <td>Delgado</td>
      </tr>
    </tbody>
  </table> 
</div>
<button onclick="logout()">Logout</button>


<script type="text/javascript" src="<?php echo e(URL::asset('js/index.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/firebase.js')); ?>"></script>

<?php $__env->stopSection(); ?>
</body>

<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>