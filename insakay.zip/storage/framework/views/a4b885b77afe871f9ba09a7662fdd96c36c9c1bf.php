<?php $__env->startSection('content'); ?>
<input type="hidden" id="uid" value="<?php echo e($uid); ?>">
<div class="main-container">
<div id="map" style="width: 100%; height: 85%"></div>
</div>
<script type="text/javascript" src="<?php echo e(URL::asset('js/panel.js')); ?>"></script>
<?php $__env->stopSection(); ?>
</body>

<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>