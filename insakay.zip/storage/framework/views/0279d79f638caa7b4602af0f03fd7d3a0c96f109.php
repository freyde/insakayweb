<?php $__env->startSection('content'); ?>
<body>
<h1>Regsiter</h1>

Account ID: <input> <br>
Password: <input> <br>
Confirm Password: <input>
<button onclick="register()">Log in</button>

</body>
<script type="text/javascript">
 
$.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
 
</script>
<?php $__env->stopSection(); ?>
</html>
<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>