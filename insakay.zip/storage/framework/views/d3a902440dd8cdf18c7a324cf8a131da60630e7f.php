<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Insakay-Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('leaflet/leaflet.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/app.css')); ?>">

    <script src='https://api.mapbox.com/mapbox-gl-js/v0.53.0/mapbox-gl.js'></script>
    <link href='https://api.mapbox.com/mapbox-gl-js/v0.53.0/mapbox-gl.css' rel='stylesheet' />
    
    <!-- <script src="https://npmcdn.com/leaflet-geometryutil"></script> -->
    <script src="<?php echo e(URL::asset('leaflet/leaflet.js')); ?>"></script>
    
    <script src="https://www.gstatic.com/firebasejs/5.8.1/firebase.js"></script>
    <script src="https://cdn.firebase.com/libs/firebaseui/3.1.1/firebaseui.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
</head>

<body>
<div class="fixed-top">
  <nav class="navbar navbar-expand-sm bg-dark navbar-dark shadow">
    <a class="navbar-brand" href="/admin"><h2>Insakay-Admin</h2></a>
    <div class="navbar-item float-right mt-0 mb-0 mr-3" style="margin-left: 75%">
      <li class="dropdown">
        <a class="dropdown-toggle font-weight-bold" href="#" data-toggle="dropdown">
          Admin
        </a>
        <div class="dropdown-menu mt-0">
          <a class="dropdown-item" href="#" onClick="logout(); return false">Logout</a>
        </div>
      </li>
    </div>
  </nav>
</div>
<nav id="sidebar" class="sidebar h-100 bg-secondary" style="max-height: 100%">
  <ul class="list-group m-1">
    <li class="list-group-item"><a href="/admin"><img class="mr-2 mb-0" src="<?php echo e(URL::asset('img/person.png')); ?>">Operators</a></li>
    <!-- <li class="list-group-item"><a href="/buses"><img class="mr-2 mb-0" src="<?php echo e(URL::asset('img/bus.png')); ?>">Buses</a></li>
    <li class="list-group-item"><a href="/routes"><img class="mr-2 mb-0" src="<?php echo e(URL::asset('img/road.png')); ?>">Route</a></li>
    <li class="list-group-item"><a href="/fare"><img class="mr-2 mb-0" src="<?php echo e(URL::asset('img/receipt.png')); ?>">Fare</a></li>
    <li class="list-group-item"><a href="/reports"><img class="mr-2 mb-0" src="<?php echo e(URL::asset('img/document.png')); ?>">Reports</a></li> -->
  </ul>
</nav>
</div>
<div id="content">
  <?php echo $__env->yieldContent('content'); ?>
</div>
</body>
<script type="text/javascript" src="<?php echo e(URL::asset('js/menu.js')); ?>"></script>
</html>