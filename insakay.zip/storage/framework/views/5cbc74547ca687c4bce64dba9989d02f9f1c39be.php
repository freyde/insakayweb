<?php $__env->startSection('content'); ?>

<input type="hidden" id="uid" value="<?php echo e($uid); ?>">
<input type="hidden" id="routeID" value="<?php echo e($infos['routeID']); ?>">


<h3 class="font-weight-bolder ml-3 mt-3"><?php echo e($routeName); ?> - FARE MATRIX</h3>
<div class="container">
<table id="matrix" class="table table-sm" style="table-layout: fixed; max-width: 100%">
    <thead>
    </thead>
    <tbody>
    <?php if($haveFare): ?>
        <tr>
            <td></td>
            <?php $__currentLoopData = $fareKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td class="font-weight-bold"><?php echo e($key); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <?php $__currentLoopData = $fares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td  class="font-weight-bold"><?php echo e($fareKeys[($loop->iteration)-1]); ?></td>
                <?php $__currentLoopData = $b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><input type="text" readonly="true" value="<?php echo e($c); ?>" style='width:6rem'></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script type="text/javascript" src="<?php echo e(URL::asset('js/havefare.js')); ?>"></script>
    <?php endif; ?>
    </tbody>
</table>
</div>

<?php if($haveFare): ?>

<?php else: ?>
<button id="saveMatrix" type="button" class="btn btn-primary" style="float: right; margin: 3rem">Save</button>
<div class="modal modal-backdrop" id="matrixLoader">
  <div class="spinner-border text-primary mx-auto fixed-top" style="margin-top: 30%"></div>
  <div class="modal-dialog"></div>
</div>

<script type="text/javascript" src="<?php echo e(URL::asset('js/fare.js')); ?>"></script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
</html>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>