<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://www.gstatic.com/firebasejs/5.8.1/firebase.js"></script>
    <script src="https://cdn.firebase.com/libs/firebaseui/3.1.1/firebaseui.js"></script>
    <!-- <script src="https://www.gstatic.com/firebasejs/5.8.1/firebase-auth.js"></script> -->
</head>
<body>

    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>