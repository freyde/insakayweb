<?php $__env->startSection('content'); ?>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="collapse navbar-collapse" id="navbarColor03">
    <ul class="navbar-nav mr-auto">
      <li class="nav-brand">
        <a class="nav-link" href="#"><h5><strong>Conductors</strong></h5></a>
      </li>
      <li class="nav-brand">
        <a class="nav-link" href="#"><h5><strong>Buses</strong></h5></a>
      </li>
      <li class="nav-brand">
        <a class="nav-link" href="#"><h5><strong>Route</strong></h5></a>
      </li>
      <li class="nav-brand">
        <a class="nav-link" href="#"><h5><strong>Fare</strong></h5></a>
      </li>
      <li class="nav-brand">
        <a class="nav-link" href="#"><h5><strong>Reports</strong></h5></a>
      </li>
    </ul>
  </div>
</nav>
<button onclick="logout()">Logout</button>
<script type="text/javascript" src="<?php echo e(URL::asset('js/index.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/firebase.js')); ?>"></script>

<?php $__env->stopSection(); ?>

</body>

<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>