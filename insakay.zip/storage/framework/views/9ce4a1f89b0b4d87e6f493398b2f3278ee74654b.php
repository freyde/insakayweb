<?php $__env->startSection('content'); ?>

<h3 class="font-weight-bolder ml-3 mt-3">Fare Management</h3>

<div class="main-container p-3">
  <table class="table table-hover">
  <?php if($routes != null): ?> 
    
        <thead>
          <tr>
            <th>Route ID</th>
            <th>Name</th>
            <th>Coverage Count</th>
            <th>Landmark Count</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($route['routeID']); ?></td>
            <td><?php echo e($route['routeName']); ?></td>
            <td><?php echo e(count($route['coverage'])); ?></td>
            <td><?php echo e($route['landmarkCount']); ?></td>
            <td>
              <form action="<?php echo e(URL::to('/fare/manage/'. $route['routeID'])); ?>" method="get">
                <input type="submit" class="btn btn-success map-btn" value="Fare Matrix"></input>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
  <table class="table">
    <thead>
        <tr align="center">
            <th>No Routes Found</th>
        </tr>
    </thead>
  </table>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
</html>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>