<?php $__env->startSection('content'); ?>

<h3 class="font-weight-bolder  ml-3 mt-3">Routes List</h3>
<input type="button" class="btn btn-primary float-right mb-2 mr-3" value="Add Route" id="addRouteBtn">

<div class="main-container p-3">
<table class="table table-hover">
<?php if($routes != null): ?> 
  <thead>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Coverage Count</th>
      <th>Landmark Count</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($route['routeID']); ?></td>
      <td><?php echo e($route['routeName']); ?></td>
      <td><?php echo e(count($route['coverage'])); ?></td>
      <td><?php echo e($route['landmarkCount']); ?></td>
      <td>
        <form action="<?php echo e(URL::to('/routes/manage/'. $route['routeID'])); ?>" method="get">
          <input type="submit" class="btn btn-success map-btn" value="Manage"></input>
        </form>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php else: ?>
  <table class="table">
    <thead>
        <tr align="center">
            <th>No Routes Found</th>
        </tr>
    </thead>
  </table>
<?php endif; ?>
</div>

<script type="text/javascript" src="<?php echo e(URL::asset('js/firebase.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/routes.js')); ?>"></script>
<?php $__env->stopSection(); ?>
</html>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>