<html>
<head>
<title>Error 403</title>
<link rel="stylesheet" href="{{URL::asset('css/error.css')}}">
</head>
<body>
<div id="notfound">
    <div class="notfound">
        <div class="notfound-404"></div>
        <h1>403</h1>
        <h2>Oops! Unauthorized</h2>
        <p>Sorry but you are not authorized to access this page. Please ask system administrator for assistance.</p>
    </div>
</div>
</body>
</html>